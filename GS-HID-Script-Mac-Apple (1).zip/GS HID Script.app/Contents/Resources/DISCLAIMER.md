# GS HID Script — Educational Use & Liability Notice

**Official GS HID Script releases are free.** GhostStrats LLC creates the software as a learning platform for keyboard/mouse automation, cybersecurity awareness, defensive research, and authorized hands-on practice.

## Responsibility for use

- Use the tool only on computers and accounts you own or have explicit permission to test.
- Review every script before running it. A script may type into another program, press keys, change settings, click controls, or overwrite content.
- You are responsible for your scripts, permissions, backups, results, and compliance with applicable laws and policies.
- GhostStrats LLC does not authorize unlawful access or malicious use, and does not supervise or control independent users.

## Modified versions and external integrations

Other people may modify GS HID Script and vendors may develop their own converters. **Independent modifications and third-party products are not authored, maintained, reviewed, certified, supported, or endorsed by GhostStrats LLC**, unless GhostStrats LLC explicitly says otherwise in writing. Their authors and distributors control their own software and representations.

## Warranty and liability

The software and materials are provided **“AS IS”** and **“AS AVAILABLE,” without warranty**. **To the fullest extent permitted by law**, GhostStrats LLC, the authors, and contributors disclaim liability for any losses, damage, corrupted files, system changes, misuse, unauthorized activities, or other consequences associated with using, modifying, distributing, or integrating the software. The complete license terms are in [`LICENSE`](LICENSE).

**This notice is not a guarantee of immunity from legal claims.** Certain responsibilities may not legally be waived. For a public release, seek advice from an attorney licensed in the relevant jurisdiction.

## Free availability

The custom **GS HID Script Free Educational Software License** permits free use, study, modification and sharing. Redistributed copies of the GS HID Script application (including modified editions) must remain free of charge and retain the required notices. Vendors can create their own converter implementations, including commercial offerings, without claiming GhostStrats endorsement.

This is a **custom source-available license**, not an OSI-approved open-source license. It replaces MIT for new distributions prepared under these terms. Copies already distributed under MIT may still retain rights under their earlier license.

GhostStrats names and original brand artwork are not granted for unauthorized endorsements or imitation of an official release.
