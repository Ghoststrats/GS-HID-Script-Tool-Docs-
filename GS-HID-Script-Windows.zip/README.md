# GS HID Script

**Safety Is an Illusion. Knowledge Is Your Failsafe.**

**GS HID Script** is a **free, beginner-friendly HID-style keyboard and mouse automation learning studio** by **GhostStrats LLC**. It helps you understand what automated keystrokes, mouse movements, clicks, delays, and shortcuts actually do—then gives you the choice to **simulate the steps in a preview or test them on your own computer**.

You do **not** need programming experience. Use the visual builder, read the plain-English commands, and follow the step-by-step explanations. More experienced users can write `.gs` scripts directly or translate supported commands to and from DuckyScript.

![GS HID Script with optional Glitch Mode](docs/images/gs-hid-script-glitch-mode.png)

**[Download](#download) · [How to use](#your-first-lesson-and-test) · [Language guide](docs/LANGUAGE-GUIDE.md) · [Vendor converter kit](integrations/vendor-converter-kit/README.md) · [License](LICENSE) · [Disclaimer](DISCLAIMER.md)**

## What is GS HID Script?

GS HID Script is both a **teaching application** and a small **human-readable scripting language**. It's built to make the kinds of input sequences demonstrated by HID automation tools understandable and testable without requiring users to learn complicated syntax first.

For example:

```text
PRESS WINDOWS + R
WAIT 1 SECOND
TYPE "notepad"
PRESS ENTER
WAIT 2 SECONDS
TYPE "Safety is an Illusion."
```

Each line is an action: press a shortcut, wait, type text, or press a key. The program can explain the actions, preview their order, and—**only when you explicitly allow it**—send real keyboard or mouse input to the currently focused window on your computer.

**Important distinction:** This is a *local software learning and automation tool*. The educational preview does not control other applications. The optional execution feature uses the local operating system's input APIs to simulate keyboard and mouse actions. The application itself is not an online service.

## What's included

### 1. Learn: built-in lessons and complete command reference

Start here if you've never used a scripting language. The **Learn** tab explains:

- What a script is and why instructions run in sequence.
- How a shortcut differs from a single key press.
- Why timing matters when opening programs or switching windows.
- How pointer coordinates, clicks, and scrolling work.
- How the program translates readable instructions into input events.
- Every recognized GS HID Script command and supported key binding.

Use **Insert in Script Lab** from the command reference to add a working example and learn by changing it.

### 2. Visual Builder: create scripts by clicking

The **Visual Builder** turns each action into an editable block. Add a typing action, choose keys, add a pause, or create mouse input. The builder generates GS HID Script in real time so you can see **exactly which code corresponds to each action**.

Windows starter recipes make it easy to create demonstrations without typing the sequence yourself:

| Recipe | What it inserts |
|---|---|
| Open Notepad | `WINDOWS + R`, wait, type `notepad`, Enter |
| Open Chrome | `WINDOWS + R`, wait, type `chrome`, Enter (Chrome must be installed/available) |
| Open CMD | Opens Windows Command Prompt through Run |
| Open PowerShell | Opens Windows PowerShell through Run |
| Open a Website | Asks for a URL and writes steps to open it with the default browser |

**Recipes only insert code.** They never execute as soon as you click them.

### 3. Script Lab: write, explain, preview, test

**GS HID Script Lab** is where you write or import `.gs` text files. It includes:

- **Load Beginner Example**: creates the full Notepad demonstration, including opening Notepad and typing a visible message.
- **Explain My Script**: checks syntax and explains each action in ordinary language.
- **Step Through Preview**: shows what will happen next without generating real input.
- **Open Script / Save .gs**: load and save text-based scripts.
- **Execute**: optional real local playback, protected by a Safety Switch and confirmation.
- **Stop**: request playback interruption.

### 4. DuckyScript ↔ GS HID Script converter

In the **Script Converter** tab:

1. Choose **DuckyScript → GS HID Script** or **GS HID Script → DuckyScript**.
2. Paste your script into the top input field.
3. Click **Convert**, then read the result in the larger box underneath.
4. Use **Flip Direction**, **Copy Output**, or **Download Output**.

Conversion is **text-only**: no keyboard/mouse actions run during conversion. The translator intentionally supports only a documented subset of DuckyScript; unsupported operations are reported rather than silently dropped. Mouse actions in GS HID Script cannot be translated into the converter's basic DuckyScript output.

### 5. Safety Switch and real input playback

GS HID Script launches with **Safety ON — scripts blocked**. You can safely learn, edit, explain, and preview scripts in this state.

When you're ready to try a script on a computer you own or are allowed to test:

1. Review the script using **Explain My Script** and **Step Through Preview**.
2. Set the **Safety Switch to OFF**.
3. Check the authorization box in the Script Lab.
4. Click **Execute** and approve the extra confirmation.
5. During the **five-second countdown**, focus the application you want to test.
6. Watch the script send input to that application.

Use **Stop** to request cancellation. On Windows, **F12** requests an emergency stop. Turning Safety ON during playback also requests a stop. These controls cannot undo actions already completed, and some actions may be in progress before the stop takes effect. Keep a harmless test window ready.

### 6. Visual design, Glitch Mode, and hidden Easter egg

The interface uses GhostStrats' black-and-purple styling. **Enable Glitch Mode** adds animated digital distortion and scanlines; switch it off at any time. There's also a hidden visual Easter egg with a Base64-encoded message and a **Decrypt Message** action. These are visual effects only and do not affect input automation.

### 7. Offline-friendly and private

The app is a local executable that opens its control panel in your own browser. The local Go program listens on a randomly selected **127.0.0.1** (loopback) port and uses a per-session token for its controls. There is no GhostStrats account, cloud hosting, or telemetry in the app. The computer's own firewall, permissions, browser, and OS input restrictions still apply.

## Download

Open **[Releases](../../releases)** and select the ZIP for your computer. The ZIP filenames are deliberately simple; the version number appears on the GitHub Release page.

| Computer | File | Application inside |
|---|---|---|
| **Windows 10/11, 64-bit** | `GS-HID-Script-Windows.zip` | `GS-HID-Script.exe` |
| **Linux, 64-bit** | `GS-HID-Script-Linux.zip` | `GS-HID-Script` |
| **Mac with Apple Silicon** (M-series) | `GS-HID-Script-Mac-Apple.zip` | `GS-HID-Script` |
| **Mac with Intel** | `GS-HID-Script-Mac-Intel.zip` | `GS-HID-Script` |

These are **portable applications**, not installers. Download the matching ZIP, extract it, and launch the application inside. The current builds are **unsigned**. Windows Smart App Control or macOS Gatekeeper may block them: **do not disable security protections to force execution**. Windows is the primary intended testing platform; some platform-specific playback features remain limited or unverified.

## Install and launch

### Windows 10/11

1. Download **`GS-HID-Script-Windows.zip`** from the release.
2. Right-click the file and choose **Extract All**.
3. Open the extracted folder and double-click **`GS-HID-Script.exe`**.
4. Your default browser opens the GS HID Script learning interface.
5. Keep the desktop program running while using the browser window.

No Python, AutoHotkey, or extra keyboard/mouse driver is required. If a security restriction blocks launch, use a permitted environment or review/build the source; don't turn off security protections.

### Linux (X11)

1. Download **`GS-HID-Script-Linux.zip`** and extract it.
2. To enable real keyboard/mouse playback on Debian, Ubuntu or Linux Mint, install the existing system utility `xdotool`:

   ```bash
   sudo apt update
   sudo apt install xdotool
   ```

3. Open a terminal in the extracted folder and run:

   ```bash
   chmod +x GS-HID-Script
   ./GS-HID-Script
   ```

The browser interface opens locally. **Learn**, the builder, the editor, and the converter are still useful without `xdotool`. Real input automation currently relies on **X11**; Wayland playback is not supported in this release. Use only authorized systems.

### macOS Apple Silicon or Intel

1. Choose the ZIP matching your Mac: **`GS-HID-Script-Mac-Apple.zip`** or **`GS-HID-Script-Mac-Intel.zip`**.
2. Extract it, open **Terminal** in the extracted folder, and run:

   ```bash
   chmod +x GS-HID-Script
   ./GS-HID-Script
   ```

3. The browser control panel opens locally. If you use real playback, macOS requires **Accessibility** permission for the application under **System Settings → Privacy & Security → Accessibility**. Some mouse operations require an optional `cliclick` utility. Input features are limited on macOS, and unsigned builds may be blocked by Gatekeeper. Do not disable security protections to force execution.

## Your first lesson and test

**Recommended: Windows + Notepad.** This gives you a visible, safe place to see every keystroke.

1. Launch GS HID Script.
2. Select **Learn** and read the basics, especially keyboard shortcuts and delays.
3. Go to **GS HID Script Lab** and choose **Load Beginner Example**.
4. Click **Explain My Script** to read the plain-English breakdown.
5. Click **Step Through Preview** to review the sequence without typing into your computer.
6. When you're ready, turn Safety OFF, check the authorization box, click **Execute**, and confirm.
7. Let the example open Notepad and type the message. Switch Safety back ON afterward.

The example creates these steps:

```text
# Launch Notepad
PRESS WINDOWS + R
WAIT 1 SECOND
TYPE "notepad"
PRESS ENTER
WAIT 2 SECONDS

# Demonstrate text input
TYPE "Hello from GS HID Script!"
PRESS ENTER
TYPE "Safety is an Illusion."
PRESS ENTER
```

Timing varies by computer. If Notepad hasn't opened when typing begins, increase the second `WAIT` value. `TYPE` only affects the currently focused application.

## GS HID Script command examples

All commands are explained in the **Learn** tab and in the [full language guide](docs/LANGUAGE-GUIDE.md).

| Command | What it means |
|---|---|
| `TYPE "Hello World"` | Types text in the active window |
| `TYPE Hello World` | Same result for regular text—quotes are optional |
| `PRESS ENTER` | Presses Enter |
| `PRESS WINDOWS + R` | Holds Windows and taps R |
| `PRESS CTRL + S` | A keyboard shortcut |
| `WAIT 1 SECOND` | Pauses one second |
| `WAIT 5 SECONDS` | Pauses five seconds (singular/plural both accepted) |
| `WAIT 500 MILLISECONDS` | Pauses half a second |
| `MOVE MOUSE TO 500, 300` | Moves pointer to X=500, Y=300 |
| `CLICK LEFT` | Performs a left click |
| `SCROLL DOWN 3` | Scrolls down three units |
| `# My comment` | Adds a note; does not run |

Quotation marks for `TYPE` are recommended for readability, but **not required** for ordinary text. Spaces at the beginning/end of the text are trimmed in the current parser. Old compatible commands such as `HOTKEY WIN+R`, `STRING Hello`, and `DELAY 1000` remain supported.

Scripts have safety limits (including script size, number of actions, and delays); see the language guide for exact values. Some OS shortcuts vary across desktop environments.

## How the application works (behind the scenes)

```text
           GS HID Script language / Visual Builder
                             |
                      Validate and explain
                             |
                Step Through Preview (no input)
                             |
                     Optional execution
                             |
                  Safety switch + approval
                             |
                 Local Go execution engine
                             |
                 OS keyboard and mouse APIs
                             |
                    Focused application
```

The same readable script drives the preview and optional execution. On **Windows**, the application uses `SendInput`. On **Linux X11**, it uses `xdotool`. On **macOS**, it uses OS-specific automation facilities with required permissions and some limitations. The result is a local *simulation of keyboard and mouse actions*, intended for learning and authorized testing.

## How to stop, disconnect, and uninstall

**Stop a script:** Select **Stop**, turn Safety ON, or use **F12** on Windows. Stop requests cannot reverse changes already made by the script.

**Disconnect the app:** Click **Disconnect GS HID Script from This Computer** near the bottom of the interface. Confirm, wait for the **Disconnected** message, then close the browser tab. If the browser is closed first, the local executable may continue running; close the desktop process or press **Ctrl+C** in the terminal if necessary.

**Uninstall:** This is a portable program, so there is no separate uninstaller. After closing it, simply delete the extracted app folder and downloaded ZIP. Your saved `.gs` files remain wherever you saved them. OS utilities installed separately (`xdotool`, optional `cliclick`) are not automatically removed.

## Troubleshooting

| Issue | What to check |
|---|---|
| App doesn't open | Extract ZIP first; confirm correct OS/CPU architecture; check OS security policy without disabling protection |
| Browser opens but shows disconnected | Check that the local executable is still running; reopen it instead of using an old tab |
| Execute button is disabled | Safety must be OFF; validate the script and check the authorization box |
| Text appears in the wrong place | Click the intended test window during the countdown; input goes to the focused application |
| Notepad example is too fast | Increase `WAIT 2 SECONDS` to `WAIT 5 SECONDS` |
| DuckyScript conversion fails | Only a subset is supported; check the line-numbered error and remove or adapt unsupported features |
| Linux input doesn't work | Use X11 and ensure `xdotool` is installed; Wayland is not supported for playback |
| macOS input doesn't work | Check Accessibility permissions, version support, and optional mouse tools |
| App was blocked by security software | Do not disable security; use the source or a signed/reviewed build when available |

## For vendors and developers

The [**Universal Vendor Converter Kit**](integrations/vendor-converter-kit/README.md) includes a documented GS HID Script grammar, a browser-compatible JavaScript parser, a platform-neutral JSON action schema, key-binding definitions, mapping examples, and conformance tests. Vendors can build their own GS HID Script translators without embedding the desktop app. Untranslatable operations must be reported rather than silently discarded.

To build the application from source, install **Go 1.22+**, then run:

```bash
go test ./...
go build -o GS-HID-Script .
```

Windows example from a suitable build environment:

```bash
CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -o GS-HID-Script.exe .
```

See [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md) for project guidelines.

## Educational use, license, and responsibility

GS HID Script is made available **free of charge by GhostStrats LLC** for educational use, cybersecurity awareness, defensive research, and authorized practice. Use it only on computers and accounts you own or have permission to test. It sends genuine local input when execution is enabled; scripts may change files or settings in the focused application.

The software is provided **"AS IS"**, without warranties. To the fullest extent permitted by law, GhostStrats LLC and contributors disclaim liability for misuse, data loss, system changes, or other consequences. These provisions cannot guarantee immunity from legal claims. See the [complete disclaimer](DISCLAIMER.md).

**License:** [GS HID Script Free Educational Software License v1.0](LICENSE). Official releases are free; distributed copies and modified editions of the application must remain free and clearly identify independent creators. Vendor converters may be independently developed under the applicable terms. This is a custom **source-available** license (not an OSI-approved open-source license). GhostStrats names and artwork may not be used to imply third-party endorsement.

---

**GhostStrats LLC · GS HID Script · Safety Is an Illusion. Knowledge Is Your Failsafe.**
