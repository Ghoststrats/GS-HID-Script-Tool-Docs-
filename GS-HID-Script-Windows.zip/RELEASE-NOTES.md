# GS HID Script — Release v0.8.6

This release focuses on clearer documentation and easier-to-identify downloads. The learning studio, plain-English GS Script, DuckyScript converter, safety switch, visual builder, Glitch Mode, and hidden Easter egg remain available.

## Downloads
- `GS-HID-Script-Windows.zip` — Windows 10/11 x64; `GS-HID-Script.exe`
- `GS-HID-Script-Linux.zip` — Linux x64; `GS-HID-Script`
- `GS-HID-Script-Mac-Apple.zip` — macOS Apple Silicon; `GS-HID-Script`
- `GS-HID-Script-Mac-Intel.zip` — macOS Intel; `GS-HID-Script`
- `GS-HID-Script-Vendor-Kit.zip` — language integration kit for vendors
- `GS-HID-Script-Repository.zip` — full GitHub source and documentation

## Notes
- The primary README now explains how to learn, preview, and test HID-style automation, including platform setup and uninstall steps.
- Setup files, downloadable archives, and executable filenames are standardized.
- Documentation now focuses on learning, previewing and locally testing HID-style input sequences.
- The program runs locally and uses permission-gated, optional input simulation.
- These executable builds are unsigned; don't disable security protections to launch them.
- Automated Go tests and vendor conformance tests are run during preparation; real input playback must still be verified on each target OS.

## License
GS HID Script Free Educational Software License v1.0 © 2026 GhostStrats LLC; see `LICENSE` and `DISCLAIMER.md`. This is a custom source-available license, not an OSI-certified open-source license. The terms have not been reviewed by an attorney.
