# GS HID Script — The Complete Language Guide

**GhostStrats GS HID Script · Beginner-friendly reference · Matches GS HID Script v0.8.6**

**Learn it. Read it. Understand it.**

GS HID Script is the plain-English scripting format used by **GhostStrats GS HID Script**. It teaches what keyboard and mouse automation does, one instruction at a time. You can write scripts yourself or build them visually in GS HID Script, preview each action, and—when you choose—run the sequence on a computer you own or are authorized to test.

> **What it does:** GS HID Script is a readable language for simulating HID-style keyboard and mouse actions directly on an authorized computer. In the app you can explain, preview and optionally execute those actions.

## 01 · Your first GS HID Script

Start with a **blank Notepad window or other disposable text document**. Then use this beginner example:

```gs
# My first GS HID Script
WAIT 1 SECOND
TYPE "Hello from GhostStrats!"
PRESS ENTER
TYPE "I am learning keyboard automation."
```

| Line | What it means |
|---|---|
| `# My first GS HID Script` | A note for humans. Nothing is typed. |
| `WAIT 1 SECOND` | Pause before the next action. |
| `TYPE "Hello from GhostStrats!"` | Type that text into the focused app. |
| `PRESS ENTER` | Press and release the Enter key. |
| `TYPE "I am learning keyboard automation."` | Type the next line of text. |

### How GS HID Script works

1. **You write** readable commands, such as `PRESS ENTER`.
2. **GS HID Script validates** the script and explains each step.
3. **You preview** actions without controlling other applications.
4. **You explicitly approve playback** if you want the local engine to send real input events.
5. **The operating system receives** those software-generated events. On Windows, GS HID Script uses the built-in `SendInput` API.

GS HID Script is not a Windows scripting standard. It is the **GS HID Script language** designed to explain and run common keyboard and mouse actions.

## 02 · Rules for writing GS HID Script

- Put **one instruction on each line**. Actions run from top to bottom.
- Commands and key names are **case-insensitive**: `press enter` works like `PRESS ENTER`.
- Use **readable words** (`PRESS`, `TYPE`, `WAIT`) rather than low-level hexadecimal input codes.
- Use `+` between simultaneous keys: `PRESS CTRL + SHIFT + S`.
- Put text inside matching double quotes for clarity: `TYPE "Hello"`. Unquoted text such as `TYPE Hello World` also works and types the same text as `TYPE "Hello World"`, but quotes are recommended.
- Use `#`, `//`, or `REM` at the **start of a line** for comments. The app does **not** support end-of-line comments after a command.
- Each `WAIT` uses a **whole number** and an explicit unit such as `SECOND`, `SECONDS`, `MILLISECOND`, `MILLISECONDS`, or `MS`.
- A `.gs` file is **plain UTF-8 text**. It can be edited in any normal text editor.
- Scripts are checked before execution. Incorrect or unsupported instructions return a line-specific error.

**Escaping quoted text:** Write `TYPE "He said \"hello\""` in the GS HID Script editor to type quotation marks within the text. Use `TYPE "C:\\Temp"` to type a backslash in a quoted string. The GS HID Script parser uses Go-style quoted-string escapes; invalid escaping is rejected.

## 03 · All supported GS HID Script commands

| Command | Example | What happens |
|---|---|---|
| `TYPE` | `TYPE "Hello!"` | Types text where the cursor is focused. |
| `PRESS` | `PRESS ENTER` | Presses and releases one key. |
| `PRESS` with `+` | `PRESS WINDOWS + R` | Presses two to four keys together, then releases them. |
| `WAIT` | `WAIT 2 SECONDS` | Pauses for the specified amount of time. |
| `MOVE MOUSE TO` | `MOVE MOUSE TO 500, 300` | Moves pointer to screen coordinate X=500, Y=300. |
| `CLICK` | `CLICK LEFT` | Clicks `LEFT`, `RIGHT`, or `MIDDLE`. |
| `SCROLL UP` | `SCROLL UP 3` | Scrolls up three units. |
| `SCROLL DOWN` | `SCROLL DOWN 2` | Scrolls down two units. |

### Typing text: `TYPE`

```gs
TYPE "GhostStrats"
TYPE "Testing on a blank document."
PRESS ENTER
```

Text goes to whichever application has keyboard focus, not necessarily the GS HID Script window. Use `TYPE` for sentences, punctuation, or mixed-case text; use `PRESS` for specific keys and shortcuts. The current engine permits **1–600 bytes of text** per typing action after parsing.

### Pressing keys: `PRESS`

```gs
PRESS ENTER
PRESS TAB
PRESS WINDOWS + R
PRESS CTRL + SHIFT + S
```

The `+` means **together**, not one after another. For instance, `PRESS CTRL + S` means hold Control, tap S, and release. A shortcut accepts **2–4 supported keys**. Shortcut effects vary by operating system and application.

### Waiting: `WAIT`

```gs
WAIT 1 SECOND
WAIT 2 SECONDS
WAIT 5 SECONDS
WAIT 500 MILLISECONDS
WAIT 250 MS
```

Use singular with one (`WAIT 1 SECOND`) and plural with multiple (`WAIT 5 SECONDS`). Both `SECOND` and `SECONDS` are accepted by the interpreter, but the Visual Builder writes grammatically natural forms.

`WAIT 1.5 SECONDS` is **not accepted**. Use `WAIT 1500 MILLISECONDS` instead. A single wait can be from **0 to 30,000 milliseconds (30 seconds)**. Timed pauses help applications finish opening or update their screens.

### Moving, clicking, and scrolling

```gs
# Move only when you know the screen layout
MOVE MOUSE TO 500, 300
WAIT 1 SECOND
CLICK LEFT
SCROLL DOWN 2
SCROLL UP 1
```

Coordinates refer to screen pixels, with **0,0 near the top-left of the primary desktop**. The first value is horizontal **X**; the second is vertical **Y**. Permitted coordinate values are **0–10,000**; these are parser bounds, not guarantees the position is on the actual display. Test mouse scripts only in a harmless, prepared window. Click values are `LEFT`, `RIGHT`, and `MIDDLE`. Scroll amounts use whole numbers from **0 to 20** in the direction specified.

## 04 · Complete keyboard binding reference

Each of these is a supported **key name in GS HID Script**. Examples below use `PRESS`, but the same key names can appear in shortcuts.

### Letters and numbers

| Category | Supported bindings | Examples |
|---|---|---|
| Letters | `A` through `Z` | `PRESS A`, `PRESS WINDOWS + R` |
| Number keys | `0` through `9` | `PRESS 1`, `PRESS CTRL + 0` |
| Function keys | `F1` through `F12` | `PRESS F1`, `PRESS CTRL + F5` |

**Tip:** `PRESS A` sends an A-key event; `TYPE "A"` is the better choice when you specifically want an uppercase text character. Keyboard layout and shift state may affect physical key events.

### Modifier keys

| Binding | Meaning | Also accepted in `PRESS` |
|---|---|---|
| `CTRL` | Control | `CONTROL` |
| `SHIFT` | Shift | — |
| `ALT` | Alt / Option on Mac | — |
| `WINDOWS` | Windows/Super key (Command on Mac backend) | `WINDOW`, `WIN`, `GUI` |
| `COMMAND` | Command on Mac; Windows key on Windows backend | `CMD` |

**Platform tip:** Prefer `WINDOWS` for Windows examples and `COMMAND` for macOS examples. GS HID Script accepts both but maps them to the platform's native modifier differently. A standalone modifier such as `PRESS CTRL` presses and releases immediately; combinations are more useful.

### Editing and navigation keys

| Key | Purpose | Accepted aliases |
|---|---|---|
| `ENTER` | Confirm or start a new line | `RETURN` |
| `TAB` | Move to next field or tab stop | — |
| `ESC` | Escape/cancel in many applications | `ESCAPE` |
| `SPACE` | Spacebar | — |
| `BACKSPACE` | Remove preceding character | — |
| `DELETE` | Delete forward or selected content | `DEL` (legacy-supported) |
| `UP` | Up arrow | — |
| `DOWN` | Down arrow | — |
| `LEFT` | Left arrow | — |
| `RIGHT` | Right arrow | — |
| `HOME` | Beginning of line or area | — |
| `END` | End of line or area | — |
| `PAGEUP` | Move one page upward | — |
| `PAGEDOWN` | Move one page downward | — |

**Not currently supported as individual key names:** `INSERT`, `PRINTSCREEN`, `NUMLOCK`, `CAPSLOCK`, `F13` and higher, numeric keypad-specific bindings, media keys, or punctuation key names such as `SEMICOLON`. Use `TYPE` to enter ordinary punctuation characters.

### Keyboard shortcuts you can recognize

| GS HID Script | Typical Windows meaning |
|---|---|
| `PRESS WINDOWS + R` | Open the Run dialog. |
| `PRESS CTRL + C` | Copy selected content. |
| `PRESS CTRL + V` | Paste from clipboard. |
| `PRESS CTRL + S` | Save in many applications. |
| `PRESS CTRL + Z` | Undo in many applications. |
| `PRESS ALT + TAB` | Switch between open windows. |
| `PRESS CTRL + SHIFT + S` | Open Save As in some applications. |
| `PRESS ESC` | Cancel or dismiss in some applications. |

These are **examples of common application/OS behavior, not guaranteed commands**: they depend on focus, permissions, and the active application. On Windows, **F12 is the GS HID Script emergency-stop key**, so avoid binding `PRESS F12` while testing scripts even though the parser recognizes `F12`.

## 05 · Mouse reference

| Action | GS HID Script | Notes |
|---|---|---|
| Move cursor | `MOVE MOUSE TO 400, 250` | Absolute position on desktop. |
| Left click | `CLICK LEFT` | Clicks item under pointer. |
| Right click | `CLICK RIGHT` | Usually opens context menu. |
| Middle click | `CLICK MIDDLE` | Supported on Windows/Linux; not implemented in the current macOS backend. |
| Scroll up | `SCROLL UP 3` | Positive direction. |
| Scroll down | `SCROLL DOWN 3` | Negative direction internally. |

`SCROLL DOWN 21` is invalid. A script can use more than one scroll instruction to scroll farther, within the overall action limit. Coordinates may differ between monitors, scaling settings, and sessions.

## 06 · Three beginner practice scripts

### Lesson A — Type a friendly message

**Before running:** Open a blank, disposable text document and focus it during the countdown.

```gs
# Practice typing on an authorized computer
WAIT 1 SECOND
TYPE "Hello! This is my first GS HID Script."
PRESS ENTER
TYPE "Safety is an Illusion."
```

### Lesson B — Understand a keyboard shortcut

**Before running:** Open a blank text document and type a few test words manually. In many Windows text editors, `CTRL + A` selects all the text.

```gs
# Select all text in my temporary test document
PRESS CTRL + A
WAIT 1 SECOND
# Do not overwrite anything; practice recognizing the selection
```

### Lesson C — See mouse coordinates

**Before running:** Open a harmless practice window and confirm that the specified coordinates point to an empty region.

```gs
# Practice a predictable mouse movement without clicking
MOVE MOUSE TO 500, 300
WAIT 2 SECONDS
MOVE MOUSE TO 300, 200
```

**Practice rule:** Start with GS HID Script's **Step Through Preview**. It explains the actions but sends no keyboard or mouse input. Use actual playback only after reviewing the exact script.

## 07 · DuckyScript-to-GS HID Script converter

GS HID Script has a **separate converter tab**. It translates a *limited, documented subset* of DuckyScript into GS HID Script. Converting text **does not run it**.

**DuckyScript input:**

```text
REM Demonstration
GUI r
DELAY 1000
STRING notepad
ENTER
```

**GS HID Script output:**

```gs
# Converted from supported DuckyScript commands into readable GS HID Script
# Review every action before pressing Execute.
PRESS WINDOWS + R
WAIT 1 SECOND
TYPE "notepad"
PRESS ENTER
```

### Supported converter commands in GS HID Script v0.8.6

| DuckyScript source | GS HID Script result or behavior |
|---|---|
| `STRING Hello` | `TYPE "Hello"` |
| `STRINGLN Hello` | `TYPE "Hello"` followed by `PRESS ENTER` |
| `DELAY 1000` | `WAIT 1 SECOND` |
| `GUI r`, `WINDOWS r`, `CMD r` | `PRESS WINDOWS + R` |
| `CTRL c`, `ALT TAB`, `SHIFT a` | Matching `PRESS` shortcut when keys are supported. |
| `ENTER`, `TAB`, `ESC`, `RETURN` and other supported individual keys | Matching `PRESS` action. |
| `REM ...` / `REM_BLOCK`…`END_REM` | Ignored comments. |
| `DEFAULT_DELAY 100` / `DEFAULTDELAY 100` | Adds a pause after later converted instructions (within limits). |
| `REPEAT 2` | Duplicates the previous converted instruction block **two additional times** in this converter. |

Converter limits: `DEFAULT_DELAY` / `DELAY` must be **0–30,000 ms**; `REPEAT` must be **1–50**. The converter is **not a full DuckyScript implementation**, and various DuckyScript versions differ in syntax. Advanced flow control, variables, payload-specific features, `ATTACKMODE`, and unsupported key names are rejected. If anything is unsupported, GS HID Script stops conversion with a line number rather than silently producing a partial script.

## 08 · Older GhostStrats command compatibility

GS HID Script's new plain-English style is recommended. **GS HID Script v0.8.6 also still accepts these older commands** so previous examples do not break:

| Older command | Modern GS HID Script |
|---|---|
| `STRING Hello` | `TYPE "Hello"` |
| `KEY ENTER` | `PRESS ENTER` |
| `HOTKEY WIN+R` | `PRESS WINDOWS + R` |
| `DELAY 1000` | `WAIT 1 SECOND` |
| `MOVE 500 300` | `MOVE MOUSE TO 500, 300` |
| `SCROLL -2` | `SCROLL DOWN 2` |
| `SCROLL 2` | `SCROLL UP 2` |
| `ENTER` | `PRESS ENTER` |

You can read legacy scripts in GS HID Script, but creating new lessons in the modern syntax is easier for beginners.

## 09 · Limits, permissions, and emergency stopping

| Rule | Current GS HID Script v0.8.6 behavior |
|---|---|
| Script size | Up to **32,768 bytes (32 KiB)**. |
| Actions | Up to **250** executable instructions. Comments do not count. |
| Total runtime | Estimated maximum **180,000 ms (3 minutes)**. |
| Single `WAIT` | **0–30,000 milliseconds**. Whole numbers only. |
| `TYPE` text | **1–600 bytes** per line/action. |
| `PRESS` shortcut | **2–4 supported keys** when using `+`. |
| Mouse coordinates | Each coordinate is a whole number **0–10,000**. |
| Scroll amount | **0–20** units up/down per command. |
| Run behavior | You must opt in and confirm; a **five-second countdown** precedes real input. |

- **Windows:** Input uses built-in `SendInput`. Hold **F12** to request a stop during playback, or use the app's Stop button. Secure desktops and elevation boundaries may restrict input.
- **Linux:** Real input uses `xdotool` in an **X11** session. Moving the pointer to the very top-left corner requests a stop. **Wayland is not supported in v0.8.5.**
- **macOS:** Requires Accessibility permission for supported actions; `cliclick` is needed for mouse control. The minimal macOS engine supports fewer keys and does **not** currently implement middle click or an OS-wide emergency-stop hotkey. Use the app's Stop button.

**Stopping is not undo:** Any input already sent may have affected the target window. Always test in an expendable file. You do not need administrator access merely to write or preview scripts.

## 10 · Troubleshooting and common mistakes

| What you see | Why | Fix |
|---|---|---|
| `GUI r` does not work as GS HID Script | `GUI r` is DuckyScript syntax. | Use the Converter tab, or write `PRESS WINDOWS + R`. |
| `WAIT 1.5 SECONDS` is rejected | Whole numbers only. | Write `WAIT 1500 MILLISECONDS`. |
| `PRESS WIN-R` is rejected | Shortcut keys use a `+` separator. | Write `PRESS WINDOWS + R`. |
| Text went into the wrong window | Keyboard focus determines the recipient. | Preview first, open a test window, and focus it during the countdown. |
| `PRESS A` doesn't make a capital A | A key event is not the same as inserting a Unicode character. | Write `TYPE "A"`. |
| `PRESS PRINTSCREEN` fails | That key name isn't supported in v0.8.5. | Use only the supported key list. |
| Mouse goes to the wrong place | Coordinates/monitor layouts differ. | Test movements without clicks and check your display setup. |
| Nothing happens on Linux | Wayland / `xdotool` requirements. | Use X11 and install `xdotool` for supported playback. |
| macOS action fails | Accessibility restrictions or minimal backend support. | Grant Accessibility permission and check supported actions. |
| Converted DuckyScript is rejected | Unsupported instruction or limit exceeded. | Review the line-numbered error; simplify the source. |

## 11 · Quick reference — memorize just these

```gs
# NOTES
# Comments begin with #, //, or REM at the start of a line.

# TEXT
TYPE "Hello!"

# KEYS
PRESS ENTER
PRESS CTRL + S
PRESS WINDOWS + R

# TIME
WAIT 1 SECOND
WAIT 500 MILLISECONDS

# MOUSE
MOVE MOUSE TO 500, 300
CLICK LEFT
CLICK RIGHT
CLICK MIDDLE
SCROLL UP 3
SCROLL DOWN 3
```

### Mini glossary

- **GS HID Script:** Readable keyboard/mouse automation instructions understood by GS HID Script.
- **Key binding:** A name for an individual key, such as `ENTER` or `F5`.
- **Shortcut / hotkey:** Keys pressed together, such as `CTRL + S`.
- **Focus:** Which window is currently receiving typing and keyboard input.
- **HID-style automation:** Input behavior like keyboard typing and mouse movement; GS HID Script can demonstrate and simulate these actions.
- **SendInput:** Built-in Windows API that GS HID Script uses for software-generated input.
- **DuckyScript:** Another human-readable keyboard automation language; GS HID Script converts a supported subset.
- **Visual Builder:** The GS HID Script learning mode for creating GS HID Script by selecting actions.

---

**GhostStrats GS HID Script · GS HID Script Language Guide · v1.0 (documentation for GS HID Script v0.8.6)**  
Free education and authorized testing. Learn the actions through explanations and preview before choosing to simulate them on your computer.
